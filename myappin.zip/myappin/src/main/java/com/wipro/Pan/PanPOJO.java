package com.wipro.Pan;

import org.springframework.stereotype.Component;

@Component("creditcard")
public class PanPOJO {
	private String panno;
	private int score;
	
	
	public PanPOJO(String panno, int score) {
		super();
		this.panno = panno;
		this.score = score;
	}
	public PanPOJO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getPanno() {
		return panno;
	}
	public void setPanno(String panno) {
		this.panno = panno;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	
	
}
