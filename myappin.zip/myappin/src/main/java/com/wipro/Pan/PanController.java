
package com.wipro.Pan;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping(value="/landing", method = RequestMethod.POST)
public class PanController{
 
	@Autowired
	private PanDAO p;
	protected ModelAndView onSubmit(@RequestParam("panno") String Pn) {
		ModelAndView m = null;
		PanDAO pdao = new PanDAO();
		double score = pdao.getScore(Pn);
		if(score>=5.0) {
			m = new ModelAndView("Success");
			//display success msg
		}
		else if(score<5.0){
			m = new ModelAndView("noteligible");//display fail msg
		}
		else if(score<0.0){
			m = new ModelAndView("invalid");//display invalid msg
		}
		return m;
	}
}
