package com.wipro.Pan;



import java.util.Iterator;
import java.util.List;

import javax.sql.DataSource;

import org.hibernate.Hibernate;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate5.HibernateTemplate;
public class PanDAO implements PanIN{
	
	private SessionFactory dataSource;
	
	
	public SessionFactory getDataSource() {
		return dataSource;
	}


	public void setDataSource(SessionFactory dataSource) {
		this.dataSource = dataSource;
	}


	@SuppressWarnings("deprecation")
	public double getScore(String Pan) {
		PanPOJO pp = new PanPOJO();
		double score = 0.0;
		HibernateTemplate ht = new HibernateTemplate(dataSource);
		try {
		@SuppressWarnings("unchecked")
		List<PanPOJO> p = (List<PanPOJO>) ht.find("from CreditCard c where c.PAN_Number=?", Pan);//returns a list
		Iterator<PanPOJO> it = p.iterator();
		if(p==null) {
			score = -1.0;
		}
		else {
		while(it.hasNext()){
			pp = p.get(0);//returns first object in the list
			score = pp.getScore();
			System.out.println("the score is:" + pp.getScore());
			}
		}
		}
		catch(Exception e) {
			System.out.println(e);
			score = -1.0;
		}
		return score;
	}
}
