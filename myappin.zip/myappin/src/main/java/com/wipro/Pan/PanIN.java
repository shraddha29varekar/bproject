package com.wipro.Pan;

public interface PanIN {
	abstract double getScore(String Pan);
}
